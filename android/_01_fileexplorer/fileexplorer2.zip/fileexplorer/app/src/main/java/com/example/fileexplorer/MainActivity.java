package com.example.fileexplorer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    int totalSelected = 0;
    EditText editView;
    ListView listView;
    TextView textView;
    Button runButton;
    MyListAdapterMy listadapter;
    ArrayList<MyListItem> listAllItems=new ArrayList<MyListItem>();
    ArrayList<MyListItem> listDispItems=new ArrayList<MyListItem>();
    private String root= Environment.getExternalStorageDirectory().getAbsolutePath();
    private String CurPath=Environment.getExternalStorageDirectory().getAbsolutePath();
    private ArrayList<String> itemFiles = new ArrayList<String>();
    private ArrayList<String> pathFiles = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initUI();
        setupPermission();
    }

    private void initUI(){
        setContentView(R.layout.activity_main);
        textView=(TextView)findViewById(R.id.textView_debug);
        setupList();
        setupAdapter();
        setupButton();
        setupFilter();
    }

    private void updateRunButtonText() {
        List<String> data = getSelectedItems();
        int len = data.size();
        if (len>0) {
            runButton.setText("(" + len + ") RUN");
        }else{
            runButton.setText("RUN");
        }
    }

    private void setupButton() {
        runButton=(Button)findViewById(R.id.button1);
        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder sb = new StringBuilder();
                sb.append("Count:"+getSelectedItemCount()+"\n");
                sb.append("path:"+CurPath+"\n");
                List<String> data = getSelectedItems();
                for(int i=0;i<data.size();i++){
                    String item = data.get(i);
                    // item 에는 file 이름이 들어옵니다.
                    // 만약 path라면 마지막에 "/" 이 더 붙도록 되어 있습니다.
                    // CurPath + item : 전체 path 를 가진 파일 이름이 됩니다.
                    sb.append(item+"\n");
                }

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("[ RUN ]")
                        .setMessage(sb.toString())
                        .setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        }).show();
                // 뭔가를 실행후에는 초기화 한다는 예제로 만들어 보았습니다.
                setupAdapter();
                updateRunButtonText();
            }
        });
        updateRunButtonText();
    }

    private void setupPermission() {
        //check for permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                }
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            }
        }
        // 안드로이드 R 이상 전체 저장소 엑세스 권한
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.addCategory("android.intent.category.DEFAULT");
                    intent.setData(Uri.parse(String.format("package:%s", getApplicationContext().getPackageName())));
                    startActivity(intent);
                } catch (Exception e) {
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivity(intent);
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        setupAdapter();
    }

    private void setupList() {
        listView=(ListView)findViewById(R.id.list1);
    }

    public class MyListItem {
        int selectedNumber;
        boolean checked;
        // for display
        String name;
        // for using ; path+name
        String path;
    }

    public class MyListAdapterMy extends MyArrayAdapter<MyListItem> {

        public MyListAdapterMy(Context context) {
            super(context,R.layout.list_item);
            totalSelected = 0;
            setSource(listDispItems);
        }
        @Override
        public void bindView(View view, MyListItem item) {
            TextView name = (TextView)view.findViewById(R.id.name_saved);
            name.setText(item.name);
            CheckBox cb = (CheckBox)view.findViewById(R.id.checkBox_saved);
            cb.setChecked(item.checked);
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View retView = super.getView(position,convertView,parent);
            final int pos = position;
            final View parView = retView;
            CheckBox cb = (CheckBox)retView.findViewById(R.id.checkBox_saved);
            cb.setOnClickListener(new View.OnClickListener() {
                // 앞쪽의 checkbox 를 클릭했을때
                @Override
                public void onClick(View view) {
                    MyListItem item = listDispItems.get(pos);
                    item.checked = !item.checked;
                    if( item.checked ) totalSelected++;
                    item.selectedNumber=totalSelected;
                    Toast.makeText(MainActivity.this,"1: Click "+pos+ "th " + item.checked + " "+totalSelected, Toast.LENGTH_SHORT).show();
                    printDebug();
                    updateRunButtonText();
                }
            });
            TextView name = (TextView)retView.findViewById(R.id.name_saved);
            name.setOnClickListener(new View.OnClickListener() {
                // 파일 목록을 클릭했을때
                @Override
                public void onClick(View view) {
                    MyListItem item = listDispItems.get(pos);
                    //item.checked = !item.checked;
                    //if( item.checked ) totalSelected++;
                    //item.selectedNumber=totalSelected;
                    //Toast.makeText(MainActivity.this,"2: Click "+pos+ "th " + item.checked + " "+totalSelected,Toast.LENGTH_SHORT).show();
                    //printDebug();
                    //bindView(parView, item);
                    itemClick(item.name,item.path);
                }
            });

            return retView;
        }
        public void fillter(String searchText) {
            listDispItems.clear();
            totalSelected = 0;
            for(int i = 0;i<listAllItems.size();i++){
                MyListItem item = listAllItems.get(i);
                item.checked = false;
                item.selectedNumber = 0;
            }
            if(searchText.length() == 0)
            {
                listDispItems.addAll(listAllItems);
            }
            else
            {
                for( MyListItem item : listAllItems)
                {
                    if(item.name.contains(searchText))
                    {
                        listDispItems.add(item);
                    }
                }
            }
            notifyDataSetChanged();
        }
    }


    public class AdapterAsyncTask extends AsyncTask<String,Void,String> {
        private ProgressDialog mDlg;
        Context mContext;

        public AdapterAsyncTask(Context context) {
            mContext = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mDlg = new ProgressDialog(mContext);
            mDlg.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            mDlg.setMessage( "loading" );
            mDlg.show();
        }
        @Override
        protected String doInBackground(String... strings) {
            // listAllItems MyListItem
            listAllItems.clear();
            listDispItems.clear();

            getDirInfo(CurPath);

            for(int i=0;i<itemFiles.size();i++){
                MyListItem item = new MyListItem();
                item.checked = false;
                item.name = itemFiles.get(i);
                item.path = pathFiles.get(i);
                listAllItems.add(item);
            }

            if (listAllItems != null) {
                Collections.sort(listAllItems, nameComparator);
            }
            listDispItems.addAll(listAllItems);
            return null;
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            mDlg.dismiss();
            listadapter=new MyListAdapterMy(mContext);
            listView.setAdapter(listadapter);

            String searchText = editView.getText().toString();
            if( listadapter!=null ) listadapter.fillter(searchText);

            textView.setText("Location: " + CurPath);
        }
        private final Comparator<MyListItem> nameComparator
                = new Comparator<MyListItem>() {
            public final int
            compare(MyListItem a, MyListItem b) {
                return collator.compare(a.name, b.name);
            }
            private final Collator collator = Collator.getInstance();
        };
    }
    private void setupAdapter() {
        listAllItems.clear();
        listDispItems.clear();
        AdapterAsyncTask adaterAsyncTask = new AdapterAsyncTask(MainActivity.this);
        adaterAsyncTask.execute();
    }
    private void setupFilter() {
        editView=(EditText)findViewById(R.id.savedfilter);
        editView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                String searchText = editView.getText().toString();
                if( listadapter!=null ) listadapter.fillter(searchText);
            }
        });
    }

    private int getSelectedItemCount() {
        int checkcnt = 0;
        for(int i=0;i<listDispItems.size();i++){
            MyListItem item = listDispItems.get(i);
            if( item.checked ) checkcnt++;
        }
        return checkcnt;
    }

    private List<String> getSelectedItems() {
        List<String> ret = new ArrayList<String>();
        int count = 0;
        for(int i=0;i<listDispItems.size();i++){
            MyListItem item = listDispItems.get(i);
            if( item.checked ) {
                if( count < item.selectedNumber ){
                    count = item.selectedNumber;
                }
            }
        }
        for(int j=1;j<=count;j++) {
            for (int i = 0; i<listDispItems.size() ;i++ ){
                MyListItem item = listDispItems.get(i);
                if( item.checked && item.selectedNumber == j){
                    ret.add(item.name);
                }
            }
        }
        return ret;
    }
    private String getSelectedItem() {
        List<String> ret = new ArrayList<String>();
        for(int i=0;i<listDispItems.size();i++){
            MyListItem item = listDispItems.get(i);
            if( item.checked ) {
                return item.name;
            }
        }
        return "";
    }
    private void printDebug() {
        StringBuilder sb = new StringBuilder();
        sb.append("Count:"+getSelectedItemCount()+"\n");
        sb.append("getSelectedItem:"+getSelectedItem()+"\n");
        sb.append("getSelectedItems:");
        List<String> data = getSelectedItems();
        for(int i=0;i<data.size();i++){
            String item = data.get(i);
            sb.append(item+",");
        }
        //textView.setText(sb.toString());
    }

    private void getDirInfo(String dirPath)
    {
        if(!dirPath.endsWith("/")) dirPath = dirPath+"/";
        File f = new File(dirPath);
        File[] files = f.listFiles();
        if( files == null ) return;

        itemFiles.clear();
        pathFiles.clear();

        if( !root.endsWith("/") ) root = root+"/";
        if( !root.equals(dirPath) ) {
            itemFiles.add("../");
            pathFiles.add(f.getParent());
        }

        for(int i=0; i < files.length; i++){
            File file = files[i];
            pathFiles.add(file.getPath());

            if(file.isDirectory())
                itemFiles.add(file.getName() + "/");
            else
                itemFiles.add(file.getName());
        }
    }

    // 리스트에서 item 클릭시 들어옵니다.
    private void itemClick(String name, String path) {
        File file = new File(path);
        if (file.isDirectory())
        {
            if(file.canRead()) {
                CurPath = path;
                setupAdapter();
            }else{
                new AlertDialog.Builder(this)
                        .setTitle("[" + file.getName() + "] folder can't be read!")
                        .setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                    }
                                }).show();
            }
        }
        else{
            new AlertDialog.Builder(this)
                    .setTitle("[" + file.getName() + "]")
                    .setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            }).show();
        }
    }


    private final long FINISH_INTERVAL_TIME = 2000;
    private long backPressedTime = 0;

    @Override
    public void onBackPressed() {
        long tempTime = System.currentTimeMillis();
        long intervalTime = tempTime - backPressedTime;

        if (0 <= intervalTime && FINISH_INTERVAL_TIME >= intervalTime) {
            // 취소키를 두번 빠르게 눌러서 나갈때 앱을 완전히 종료 시킨다.
            super.onBackPressed();
            this.finish();
        } else {
            backPressedTime = tempTime;
            Toast.makeText(this, "\'뒤로\' 버튼을 한번 더 누르시면 종료됩니다", Toast.LENGTH_SHORT).show();
        }
    }

}